# OmniMind Sovereign Kuramoto

Clean-room Rust implementation of:
- **SovereignKuramotoSolver**: Kuramoto + hyper-Kuramoto + INRC field + psychoanalytic coupling
- **PsychoanalyticLIF**: LIF neuron with neutrosophic dynamic threshold (T,I,F)
- **HopfBifurcationMonitor**: Spectral radius monitoring + regime classification

## Build

```bash
cargo build --release
```

## Python bridge

The `__init__.py` provides a Python fallback when the Rust `.so` is not available.

## License

CC-BY-NC-ND-4.0 (OmniMind Sovereign Federation)
